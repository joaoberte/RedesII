#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <linux/if_packet.h>

#define BUFFER_SIZE 2000
#define ETHERTYPE 0x0800


typedef struct pacoteIPv6{ 
	unsigned char version:4;
	unsigned char trafficClass;
	unsigned int flowLabel:20;
	unsigned char payload[2];
	unsigned char nextHeader;
	unsigned char hopLimit;
	unsigned char protocol;
	unsigned char ipSource[16];
	unsigned char ipDestination[16];
}pacoteIPv6; 

typedef struct pacoteTCP {
	unsigned char portSource[2];
    unsigned char portDestination[2];
	unsigned char sequenceNumber[4];
	unsigned char ackNumber[4];
	unsigned char dataOffSet:4;
	unsigned char reserved:3;
    unsigned int flags:9;
    unsigned char windowSize[2];
    unsigned short checksum;
    unsigned char urgentPointer[2];
    //talvez precise do campo option
} pacoteTCP;


int contemCaracter(char palavra[], char letra) 
{
    for (int i = 0; palavra[i]; i++) {
        if(palavra[i] == letra) {
            return 1;
        }
    }
    return 0;
}

void mostraResultado(char palavra[], char encontradas[]) 
{
    int flagEncontrada = 0;
    for (int i = 0; palavra[i]; i++) {
        for(int j = 0; encontradas[j]; j++){
            if(palavra[i] == encontradas[j]) {
                printf("%c ", encontradas[j]);
                flagEncontrada = 1;
            }
        }
        if(!flagEncontrada){
            printf("_ ");
        }
        flagEncontrada = 0;
    }
}

int main(int argc, char *argv[])
{
	int fd;
    int tentativas = 8;
    int qntLetrasEnc = 0;
	unsigned char buffer[BUFFER_SIZE];
	struct ifreq ifr;
	char ifname[IFNAMSIZ];
	pacoteIPv6 *pPacoteIPv6 = NULL;
	pacoteTCP *pPacoteTCP = NULL;
    char palavra[30];
    char letrasEncontradas[30];

	if (argc != 3) {
		printf("Usage: %s iface palavra\n", argv[0]);
		return 1;
	}
	strcpy(ifname, argv[1]);
    strcpy(palavra, argv[2]);

	/* Cria um descritor de socket do tipo RAW */
	fd = socket(PF_PACKET,SOCK_RAW, htons(ETH_P_ALL));
	if(fd < 0) {
		perror("socket");
		exit(1);
	}

	/* Obtem o indice da interface de rede */
	strcpy(ifr.ifr_name, ifname);
	if(ioctl(fd, SIOCGIFINDEX, &ifr) < 0) {
		perror("ioctl");
		exit(1);
	}

	/* Obtem as flags da interface */
	if (ioctl(fd, SIOCGIFFLAGS, &ifr) < 0){
		perror("ioctl");
		exit(1);
	}

	/* Coloca a interface em modo promiscuo */
	ifr.ifr_flags |= IFF_PROMISC;
	if(ioctl(fd, SIOCSIFFLAGS, &ifr) < 0) {
		perror("ioctl");
		exit(1);
	}

	printf("Esperando pacotes ... \n");
	while (1) {
		unsigned char mac_dst[6];
		unsigned char mac_src[6];
		short int ethertype;

		/* Recebe pacotes */
		if (recv(fd,(char *) &buffer, BUFFER_SIZE, 0) < 0) {
			perror("recv");
			close(fd);
			exit(1);
		}
        
		/* Copia o conteudo do cabecalho Ethernet */
		memcpy(mac_dst, buffer, sizeof(mac_dst));
		memcpy(mac_src, buffer+sizeof(mac_dst), sizeof(mac_src));
		memcpy(&ethertype, buffer+sizeof(mac_dst)+sizeof(mac_src), sizeof(ethertype));
		ethertype = ntohs(ethertype);

		pPacoteIPv6 = (struct pacoteIPv6 *)(buffer+sizeof(mac_dst)+sizeof(mac_src)+sizeof(ethertype));

		pPacoteTCP = (struct pacoteTCP *)(buffer+sizeof(mac_dst)+sizeof(mac_src)+sizeof(ethertype)+(sizeof(struct pacoteIPv6)));

		if (pPacoteIPv6->version == 0x06) {
			printf("Cabecalho Ethernet: \n");

			printf("MAC destino: %02x:%02x:%02x:%02x:%02x:%02x\n", 
                        mac_dst[0], mac_dst[1], mac_dst[2], mac_dst[3], mac_dst[4], mac_dst[5]);

			printf("MAC origem:  %02x:%02x:%02x:%02x:%02x:%02x\n", 
                        mac_src[0], mac_src[1], mac_src[2], mac_src[3], mac_src[4], mac_src[5]);

			printf("EtherType: 0x%04x\n", ethertype);

			printf("\n\nCabecalho Ipv4: \n");
			
			printf("version: 0x%01x\n", pPacoteIPv6->version);

			printf("traffic Class: 0x%01x\n", pPacoteIPv6->trafficClass);
			
			printf("Hlen: 0x%02x\n", pPacoteIPv6->flowLabel);

			printf("payload: 0x%02x%02x\n", pPacoteIPv6->payload[0], pPacoteIPv6->payload[1]);
			
			printf("next Header: 0x%02x\n", pPacoteIPv6->nextHeader);

			printf("hop Limit: %02x\n", pPacoteIPv6->hopLimit);

			printf("Protocolo: 0x%02x\n", pPacoteIPv6->protocol);

			printf("IP Origem: %d.%d.%d.%d\n", pPacoteIPv6->ipSource[0], pPacoteIPv6->ipSource[1], 
			pPacoteIPv6->ipSource[2], pPacoteIPv6->ipSource[3]);

			printf("IP Destino: %d.%d.%d.%d\n", pPacoteIPv6->ipDestination[0], pPacoteIPv6->ipDestination[1], 
			pPacoteIPv6->ipDestination[2], pPacoteIPv6->ipDestination[3]);
			
			printf("\n\nCabecalho UDP: \n");

			printf("Porta Origem: 0x%02x%02x\n", pPacoteTCP->portSource[0], pPacoteTCP->portSource[1]);

			printf("Porta Dentino: 0x%02x%02x\n", pPacoteTCP->portDestination[0], pPacoteTCP->portDestination[1]);

			printf("sequence Number: 0x%02x%02x\n", pPacoteTCP->sequenceNumber[0], pPacoteTCP->sequenceNumber[1]);

			printf("Checksum: 0x%02x\n", pPacoteTCP->checksum);

			printf("Letra da jogada: %c\n", pPacoteTCP->letra);

			printf("\n\n");
            
            if(tentativas > 0)
            {
                if(contemCaracter(palavra, pPacoteTCP->letra)){
                    letrasEncontradas[qntLetrasEnc] = pPacoteTCP->letra;
                    qntLetrasEnc++;
                    mostraResultado(palavra, letrasEncontradas);
                    printf("\nTentativas restantes: %d\n", tentativas);
                }else{
                    tentativas--;
                    mostraResultado(palavra, letrasEncontradas);
                    printf("\nLetra Inexistente, Tentativas restantes: %d\n", tentativas);
                }
            }else{
                printf("\nAcabaram suas tentativas\n");
            }

            printf("\n\n");

		}
	}

	close(fd);
	return 0;
}
